package com.sathyatell.calldetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
@EnableDiscoveryClient
@SpringBootApplication
public class MicroServiceCallDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServiceCallDetailsApplication.class, args);
	}

}
