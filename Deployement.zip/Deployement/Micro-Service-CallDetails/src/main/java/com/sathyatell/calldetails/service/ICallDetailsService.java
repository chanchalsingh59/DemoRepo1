package com.sathyatell.calldetails.service;

import java.util.List;

import com.sathyatell.calldetails.dto.CallDetailsDTO;

public interface ICallDetailsService {

		List<CallDetailsDTO> getCallDetailsByPhoneNumber(Long calledBy);
}
