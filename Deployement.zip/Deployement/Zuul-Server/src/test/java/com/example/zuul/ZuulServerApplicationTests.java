package com.example.zuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
