package com.sathyatell.plandetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.sathyatell.plandetails.dto.PlanDetailsDTO;
import com.sathyatell.plandetails.service.IPlanDetailsService;

@RestController
public class PlanDetailsRestController {
	@Autowired
	private IPlanDetailsService service;

	@GetMapping("/allPlans")
	public List<PlanDetailsDTO> getAllPlans()
	{
		return service.getAllPlans();
	}

	@GetMapping("/{planId}")
	public PlanDetailsDTO getPlanByPlanId(@PathVariable("planId")String planId)
	{
		System.out.println("handler of plandetails");

		return service.getPlanByPlanId(planId);
	}

	@GetMapping("/changePlan")
	public List<PlanDetailsDTO> listPlans()
	{
		return service.getAllPlans();
	}
}
