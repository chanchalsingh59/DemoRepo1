package com.example.eureka;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
